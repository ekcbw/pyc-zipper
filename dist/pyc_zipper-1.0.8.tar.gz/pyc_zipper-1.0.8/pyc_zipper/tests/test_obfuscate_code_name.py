def f():pass

print(repr(f.__name__))