class A:
    def __init__(self):
        self.super=super()

a=A()
print(a.super)